/*
 * Error comment: /*  */
 */

int main () {
  return 0;
}
