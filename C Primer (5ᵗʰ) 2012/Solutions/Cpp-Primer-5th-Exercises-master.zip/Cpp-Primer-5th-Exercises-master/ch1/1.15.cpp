#include <iostream>
int main( {
  std::cout << "Read each file." << std::endl:
  std::cout << Update master. << std::endl;
  std::cout << "Write new master." std::endl;
  return 0
}
